import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;
import java.util.zip.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

class strukt{//trida pro data
    public String kod="";
    public String name="";
    public String kodFrom="";

}






public class main {

    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException {
        new FileOutputStream("20210430_OB_573060_UZSZ.xml.zip").getChannel().transferFrom(Channels.newChannel(new URL("https://vdp.cuzk.cz/vymenny_format/soucasna/20210531_OB_573060_UZSZ.xml.zip").openStream()), 0, Long.MAX_VALUE);
        try {
            String path = System.getProperty("user.dir");
            System.out.println(path+"\\20210430_OB_573060_UZSZ.xml.zip");
            ZipInputStream zin = new ZipInputStream(new FileInputStream(path+"\\20210430_OB_573060_UZSZ.xml.zip"));
            ZipEntry entry=zin.getNextEntry();
            FileOutputStream fout = new FileOutputStream(path+"\\20210430_OB_573060_UZSZ.xml");
            for (int c = zin.read(); c != -1; c = zin.read()) {
                fout.write(c);
            }
            fout.flush();
            zin.closeEntry();
            fout.close();
        }
        catch (FileNotFoundException ex){
            System.out.println("file not exist");
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("unzip success");
        //parser
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = documentBuilder.parse("20210430_OB_573060_UZSZ.xml");
        Node root = document.getDocumentElement();
        NodeList doc = root.getChildNodes();
        Vector<strukt> v1 = new Vector<strukt>();
        Node mistoHlavicka = doc.item(3);
        for(int i = 0; i < mistoHlavicka.getChildNodes().getLength(); i++){
            Node mistodata= mistoHlavicka.getChildNodes().item(i);
            for(int j = 0; j < mistodata.getChildNodes().getLength(); j++){
                if(mistodata.getChildNodes().item(j).getNodeType() != Node.TEXT_NODE) {
                    strukt struk = new strukt();
                    String nameOfNode = mistodata.getChildNodes().item(j).getChildNodes().item(1).getNodeName().split(":")[0];//ziskame unikalni atribut <obi:Kod>->obi
                    Node smallShit = mistodata.getChildNodes().item(j);
                    String nameKod = nameOfNode + ":Kod";
                    String nameNazev = nameOfNode + ":Nazev";
                    for(int p = 0; p < smallShit.getChildNodes().getLength(); p++){

                        if (smallShit.getChildNodes().item(p).getNodeName().equals(nameKod)  ||smallShit.getChildNodes().item(p).getNodeName().equals(nameNazev) ){

                            if(smallShit.getChildNodes().item(p).getNodeName().equals(nameKod))
                                struk.kod=smallShit.getChildNodes().item(p).getTextContent() + nameOfNode;//pridavame kod mista
                            else
                                struk.name=smallShit.getChildNodes().item(p).getTextContent();//pridavame nazev mista

                        }
                        if(smallShit.getChildNodes().item(p).getChildNodes().getLength()==3){
                            if(smallShit.getChildNodes().item(p).getChildNodes().item(1).getNodeName().split(":")[1].equals("Kod")){

                                if(struk.kodFrom.equals("")){
                                    struk.kodFrom = smallShit.getChildNodes().item(p).getChildNodes().item(1).getTextContent() + smallShit.getChildNodes().item(p).getChildNodes().item(1).getNodeName().split(":")[0];//pridavame kam patri to misto
                                }
                            }
                        }
                    }
                    if(!struk.kod.equals(""))//kdyz nemame kod(primarni klic) nemuzeme data pouzit
                        v1.add(struk);
                }
            }
        }
        for(int i =0;i<v1.size();i++){
            System.out.println(v1.get(i).kod+" "+v1.get(i).kodFrom+" "+v1.get(i).name);//vypis vsech dat
        }
        if(DB(v1)==1){
            System.out.println("success");
        }
    }
    public static int DB(Vector<strukt> v1){
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/postgres";
            String login = "postgres";
            String password = "root";
            Connection con = DriverManager.getConnection(url, login, password);
            Statement stmt = con.createStatement();
            String name;
            String kod;
            String kodFrom;
            v1.get(0).kodFrom="";//<vf:Obec gml:id="OB.573060"> nemuze mit atribut kodFrom
            for (int i = 0;i<v1.size();i++){
                kod = "'"+v1.get(i).kod+"'";
                if(v1.get(i).name.equals(""))
                    name = "NULL";
                else
                    name = "'"+v1.get(i).name+"'";
                if(v1.get(i).kodFrom.equals(""))
                    kodFrom = "NULL";
                else
                    kodFrom = "'"+v1.get(i).kodFrom+"'";
                stmt.executeUpdate("insert into misto (misto_klic, misto_misto_klic,nazev) values ("+kod+","+kodFrom +","+name+")");
            }
            return 1;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}
